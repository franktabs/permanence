import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-accueil',
  templateUrl: './page-accueil.component.html',
  styleUrls: ['./page-accueil.component.scss', "../shared/styles/styles.scss"]
})
export class PageAccueilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
