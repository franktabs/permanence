import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-rapport',
  templateUrl: './page-rapport.component.html',
  styleUrls: ['./page-rapport.component.scss', "../shared/styles/styles.scss"]
})
export class PageRapportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
