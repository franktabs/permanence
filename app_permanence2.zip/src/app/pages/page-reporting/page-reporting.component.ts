import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-reporting',
  templateUrl: './page-reporting.component.html',
  styleUrls: ['./page-reporting.component.scss', "../shared/styles/styles.scss"]
})
export class PageReportingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
