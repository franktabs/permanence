import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-holiday',
  templateUrl: './modal-holiday.component.html',
  styleUrls: ['./modal-holiday.component.scss']
})
export class ModalHolidayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
