import { IApiDepartement } from "../../interfaces/iapidepartement";
import ModelRequest from "./ModelRequest";


export default class DepartementRequest<T> extends ModelRequest<T>{
    
}