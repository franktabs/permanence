import { IModel } from "../../interfaces/imodel";
import ModelRequest from "./ModelRequest";

export default class DirectionRequest<T> extends ModelRequest<T>{}