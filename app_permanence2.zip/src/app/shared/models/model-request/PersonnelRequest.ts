import ModelRequest from "./ModelRequest";


export default class PersonnelRequest<T> extends ModelRequest<T>{}