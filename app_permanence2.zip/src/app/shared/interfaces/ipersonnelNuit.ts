import { IPersonnelJour } from "./ipersonneljour";

export interface IPersonnelNuit extends IPersonnelJour{}