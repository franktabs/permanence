import { IPersonnel } from "./ipersonnel";

export interface IHolidays{
    id:number;
    debut:string;
    fin:string;
    submissionDate:string
}