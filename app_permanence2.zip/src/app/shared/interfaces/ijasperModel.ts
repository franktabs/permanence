
export default interface IJasperModel{
    title:string;
}