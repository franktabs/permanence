

export interface IModel{}